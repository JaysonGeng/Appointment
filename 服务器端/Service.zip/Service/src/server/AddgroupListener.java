
//添加群组的监听器

package server;



import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import connect.AConnection.OnRecevieMsgListener;
import connect.AConnectionManager;
import main.Service;
import message.AMessage;
import message.AMessageType;
import message.GroupList;

public class AddgroupListener extends MessageSender implements OnRecevieMsgListener 
{
	Connection connection = Service.con1;

	public void onReceive(AMessage fromOneClient)
	{
		try{
			Statement statement = connection.createStatement();

			//向数据库修改群组的成员信息
			if (AMessageType.MSG_TYPE_ADDGROUP.equals(fromOneClient.type))
			{
				long c=fromOneClient.to,w=fromOneClient.from;
				ResultSet rs;
				try {
					rs = statement.executeQuery( "SELECT * FROM groups;" );

					while ( rs.next() )
					{
						long d=rs.getInt("number");
						if(d==c)
						{
							String sql = "UPDATE groups set MEMBER = '"+rs.getString("member")+"/"+w+"' where NUMBER = "+c+";";
							statement.executeUpdate(sql);
//							Service.con1.commit();
						}
					}
					rs.close();

					//生成新的群组列表
					AConnectionManager.grouplist=new GroupList();

					//把新的群组列表发给所有客户端
					AMessage toAllClient = new AMessage();
					GroupList grouplist=AConnectionManager.grouplist;
					toAllClient.content = grouplist.toJson();
					toAllClient.type = AMessageType.MSG_TYPE_GROUPLIST;
					toEveryClient(toAllClient);
				} catch (SQLException | IOException e) {
					e.printStackTrace();
				}
			}


		}
		catch (Exception e){
			e.printStackTrace();
		}

		
	}

}
