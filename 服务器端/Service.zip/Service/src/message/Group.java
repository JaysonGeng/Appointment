
//描述群组信息的类

package message;

public class Group extends ProtocalObj {
	public long number;			// 群号
	public String name = "";	// 群名称
	public int avatar;			// 头像(未用)
	public String member="";	//成员
	public String describe="";	//群组介绍
}
