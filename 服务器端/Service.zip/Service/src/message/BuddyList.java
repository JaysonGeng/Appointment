
//存储数据库用户的类，默认为空，在Db里添加

package message;



import java.util.ArrayList;
import java.util.List;

public class BuddyList extends ProtocalObj {
	public List<Buddy> buddyList = new ArrayList<Buddy>();
}
