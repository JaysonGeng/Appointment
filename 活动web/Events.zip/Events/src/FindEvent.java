import post.JDBC;
import post.Event;
import post.User;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FindEvent extends HttpServlet {
    String jsp = "list.jsp";

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int userId = 0;
        int operation = 0;
        ArrayList<Event> eventList;
        try {
            userId = Integer.parseInt(request.getParameter("userid"));
            operation = Integer.parseInt(request.getParameter("operation"));
        } catch (Exception e) {//
        }
        if (operation == 0) {
            eventList = JDBC.getInstance().getEventList();
        } else {
            User user = JDBC.getInstance().getUser(userId);
            eventList = JDBC.getInstance().getEventList(user.getEventId());
        }
        request.setAttribute("eventList", eventList);
        request.setAttribute("userId", userId);
        request.getRequestDispatcher(jsp).forward(request, response);
    }
}