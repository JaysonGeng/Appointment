import post.JDBC;
import post.Event;
import post.User;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AddEvent extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int userId = 0;
        int eventId = 1;
        try {
            eventId = Integer.parseInt(request.getParameter("eventid"));
            userId = Integer.parseInt(request.getParameter("userid"));
        } catch (Exception e) {
        }
        User user = JDBC.getInstance().getUser(userId);
        String str = String.format("UPDATE %s SET %s = '%s' WHERE %s = %s", "users", "event_id", user.addEvent(eventId), "NUMBER", userId);
        JDBC.getInstance().add(str);
        JDBC.getInstance().add_number_in_group(userId,eventId);

        //response.getWriter().println("<h1>Done</h1>");
        request.getRequestDispatcher("Mylist").forward(request, response);

    }
}