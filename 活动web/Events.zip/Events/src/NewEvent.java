import post.JDBC;
import post.Event;
import post.User;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class NewEvent extends HttpServlet {
    String jsp = "NewEvent.jsp";

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int userId = 0;
        int opreation = 0;
        String title = "";
        String content = "";
        String location = "";
        String time = "";
        String userid = "";
        try {
            userId = Integer.parseInt(request.getParameter("userid"));
            opreation = Integer.parseInt(request.getParameter("operation"));
            title = request.getParameter("title");
            content = request.getParameter("content");
            location = request.getParameter("location");
            time = request.getParameter("time");
            userid = request.getParameter("userid");
        } catch (Exception e) {

        }
        if (opreation == 0) {
            request.setAttribute("userId", userId);
            request.getRequestDispatcher(jsp).forward(request, response);
        } else {
            Event event = new Event(title, content, time, location, userid);
            event.upload();
            JDBC.getInstance().add_new_group(event.getEventid(), title, content, userid);
            JDBC.getInstance().add_number_in_group(userId, Integer.valueOf(event.getEventid()));
            User user = JDBC.getInstance().getUser(Integer.valueOf(userid));
            String str2 = String.format("UPDATE %s SET %s = '%s' WHERE %s = %s", "users", "event_id", user.addEvent(Integer.valueOf(event.getEventid())), "NUMBER", userid);
            JDBC.getInstance().add(str2);
        }

        request.setCharacterEncoding("utf-8");

        response.setContentType("text/html; charset=UTF-8");
        response.getWriter().println("<h1>发起活动成功，\n你已加入活动聊天室</h1>");

    }
}
