package post;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

import java.sql.ResultSet;
import java.util.ArrayList;

public class Event {
    int id;
    //    int eventId;
    String title = "0000";
    String content = "0000";
    String time;
    String location;
    int organizerId;
    User organizer;//发起人
    int[] partUserId;
    ArrayList<User> partUser;//参与者
    String postTime = "0000";//临时
    String lastTime;//持续时间
    String eventid = null;

    public String getEventid(){
        return eventid;
    }

    public User getOrganizer() {

        this.organizer = JDBC.getInstance().getUser(organizerId);
        return organizer;
    }

    public Event() {
    }

    public Event(String title, String content, String time, String location, String organizerId) {
        this.title = title;
        this.content = content;
        this.time = time;
        this.location = location;
        this.organizerId = Integer.parseInt(organizerId);
    }

    //临时
    public void upload() {
        String str = String.format("INSERT INTO events VALUES (null, '%s', '%s', '%s', '%s', '%s', %s, %s, %s)", title, content, time, location, organizerId, null, null, null);
        System.out.println(str);
        eventid = JDBC.getInstance().addreturneventid(str);
    }

    //region Getter & Setter
    public int getOrganizerId() {
        return organizerId;
    }

    public void setOrganizerId(int organizerId) {
        this.organizerId = organizerId;
    }

    public int[] getPartUserId() {
        return partUserId;
    }

    public void setPartUserId(int[] partUserId) {
        this.partUserId = partUserId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

//    public int getEventId() {
//        return eventId;
//    }
//
//    public void setEventId(int eventId) {
//        this.eventId = eventId;
//    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setOrganizer(User organizer) {
        this.organizer = organizer;
    }

    public ArrayList<User> getPartUser() {
        return partUser;
    }

    public void setPartUser(ArrayList<User> partUser) {
        this.partUser = partUser;
    }

    public String getPostTime() {
        return postTime;
    }

    public void setPostTime(String postTime) {
        this.postTime = postTime;
    }

    public String getLastTime() {
        return lastTime;
    }

    public void setLastTime(String lastTime) {
        this.lastTime = lastTime;
    }
    //endregion
}
