package post;

import java.util.ArrayList;

public class User {
    int id;
    String name;
    String avatarURL;//头像地址
    int[] eventId;
    ArrayList<Event> eventList = new ArrayList<>();//参与的活动

    public ArrayList<Event> getEventList() {
        this.eventList = JDBC.getInstance().getEventList(eventId);
        return eventList;
    }


    //临时
    public String addEvent(int eventId) {
        String str = "";
        for (int i = 0; i < this.eventId.length; i++) {
            if (this.eventId[i] != eventId&&this.eventId[i]!=0)
                str += this.eventId[i] + "|";
        }
        str += eventId;
        return str;
    }


    //region Getter & Setter
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAvatarURL() {
        return avatarURL;
    }

    public void setAvatarURL(String avatarURL) {
        this.avatarURL = avatarURL;
    }

    public void setEventList(ArrayList<Event> eventList) {
        this.eventList = eventList;
    }

    public int[] getEventId() {
        return eventId;
    }

    public void setEventId(int[] eventId) {
        this.eventId = eventId;
    }
    //endregion
}
