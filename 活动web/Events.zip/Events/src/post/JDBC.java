package post;

import com.sun.org.apache.regexp.internal.RE;

import java.sql.*;
import java.util.ArrayList;

public class JDBC {

    public static Connection connection = null;
    private Statement statement = null;
    private static final String Class_Name = "com.mysql.jdbc.Driver";
    private String url = "jdbc:mysql://202.194.15.234:3306/MyStudentOnline?useUnicode=true&characterEncoding=UTF-8";
    private String user = "root";
    private String password = "Michael.OD_1231013";

    private JDBC() {
        try {
            connection = createConnection(url, user, password);
            statement = connection.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private static JDBC instance = new JDBC();

    public static JDBC getInstance() {
        return instance;
    }

    public static Connection createConnection(String url, String user, String password) throws SQLException, ClassNotFoundException {
        Class.forName(Class_Name);
        return DriverManager.getConnection(url, user, password);
    }//getInstance()方法在此。


    public Event getEvent(int eventId) {
        String sql = "select * from events WHERE id = " + eventId;
        Event event = new Event();
        try {
            ResultSet eventResultSet = statement.executeQuery(sql);
            while (eventResultSet.next()) {
                event.setId(eventResultSet.getInt("id"));
//                event.setEventId(eventResultSet.getInt("event_id"));
                event.setTitle(eventResultSet.getString("title"));
                event.setContent(eventResultSet.getString("content"));
                event.setTime(eventResultSet.getString("time"));
                event.setLocation(eventResultSet.getString("location"));
                event.setPartUserId(str2Id(eventResultSet.getString("part_id")));
                event.setOrganizerId(Integer.parseInt(eventResultSet.getString("organizer_id")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return event;
    }

    public User getUser(int userId) {
        User user = new User();
        String sql = "select * from users WHERE NUMBER = " + userId;
        try {
            ResultSet userResultSet = statement.executeQuery(sql);
            while (userResultSet.next()) {
                user.setId(userResultSet.getInt("NUMBER"));
                user.setName(userResultSet.getString("NAME"));
                user.setAvatarURL(userResultSet.getString("avatarurl"));
                user.setEventId(str2Id(userResultSet.getString("event_id")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }

    public ArrayList<User> getUser_inSameGroup(String groupId) {           //获取加入同一个活动的用户
        ArrayList<User> arrayList = new ArrayList<>();


        try {
            String sql = "select * from users";
            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()) {
                boolean flag = false;
                String group = resultSet.getString("event_id");
                //System.out.println(group);
                String[] sum = group.split("\\|");
                for (int i = 0; i < sum.length; i++) {
                    if (sum[i].equals(groupId)) {
                        flag = true;
                        break;
                    }
                }

                if (flag) {
                    User user = new User();
                    user.setId(resultSet.getInt("NUMBER"));
                    user.setName(resultSet.getString("NAME"));
                    //System.out.println(user.getName());
                    user.setAvatarURL(resultSet.getString("avatarurl"));
                    arrayList.add(user);

                    flag = false;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


        return arrayList;

    }


    public ArrayList<Event> getMyList(int userID) {
        ArrayList<Event> arrayList = new ArrayList<>();
        try {
            String sql = "select * from users WHERE NUMBER = " + userID;
            Statement statement2 = connection.createStatement();
            ResultSet resultSet = statement2.executeQuery(sql);
            while (resultSet.next()) {
                String result = resultSet.getString("event_id");
                String[] sum = result.split("\\|");
                int[] sums = new int[sum.length];
                for (int i = 0; i < sums.length; i++) {
                    sums[i] = Integer.parseInt(sum[i]);
                }
                for (int i = 0; i < sums.length; i++) {
                    arrayList.add(getEvent(sums[i]));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return arrayList;
    }

    public ArrayList<Event> getEventList(int[] eventId) {
        ArrayList<Event> eventList = new ArrayList<>();
        for (int i = 0; i < eventId.length; i++) {
            eventList.add(getEvent(eventId[i]));
        }
        return eventList;
    }

    public ArrayList<User> getUserList(int[] userId) {
        ArrayList<User> userList = new ArrayList<>();
        for (int i = 0; i < userId.length; i++) {
            userList.add(getUser(userId[i]));
        }
        return userList;
    }


    public ArrayList<Event> getEventList() {
        String sql = "select * from events";
        ArrayList<Event> eventList = new ArrayList<>();
        try {
            ResultSet eventResultSet = statement.executeQuery(sql);
            while (eventResultSet.next()) {
                Event event = new Event();
                event.setId(eventResultSet.getInt("id"));
//                event.setEventId(eventResultSet.getInt("event_id"));
                event.setTitle(eventResultSet.getString("title"));
                event.setContent(eventResultSet.getString("content"));
                event.setTime(eventResultSet.getString("time"));
                event.setLocation(eventResultSet.getString("location"));
                event.setPartUserId(str2Id(eventResultSet.getString("part_id")));
                event.setOrganizerId(Integer.parseInt(eventResultSet.getString("organizer_id")));
                eventList.add(event);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return eventList;
    }

    public ArrayList<User> getUserList() {
        ArrayList<User> userList = new ArrayList<>();
        String sql = "select * from users";
        try {
            ResultSet userResultSet = statement.executeQuery(sql);
            while (userResultSet.next()) {
                User user = new User();
                user.setId(userResultSet.getInt("NUMBER"));
                user.setName(userResultSet.getString("NAME"));
                user.setAvatarURL(userResultSet.getString("avatarurl"));
                user.setEventId(str2Id(userResultSet.getString("event_id")));
                userList.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return userList;
    }


    public static String addId(String originalStr, int ID) {
        return originalStr + ID + "|";
    }

    public static int[] str2Id(String str) {
        int[] temp = {0};
        if (str == null) {
            return temp;
        }
        String[] strs = str.split("\\|");
        int[] res = new int[strs.length];
        for (int i = 0; i < strs.length; i++) {
            try {
                res[i] = Integer.parseInt(strs[i]);
            } catch (NumberFormatException e) {
                return temp;
            }
        }
        return res;
    }


    public void add(String sql) {//TODO 临时的解决方案。
        try {
            statement.executeUpdate(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public String addreturneventid(String sql) {
        ResultSet re = null;
        String eventid = null;
        try {
            statement.executeUpdate(sql, Statement.RETURN_GENERATED_KEYS);
            re = statement.getGeneratedKeys();
            if (re.next()) {
                eventid = String.valueOf(re.getInt(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return eventid;
    }

    public void add_number_in_group(int userId, int groupid) {
        try {
            boolean flag = true;
            String sql = "select * from groups where number =" + (groupid + 100000);
            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()) {
                String res = resultSet.getString("member");
                System.out.println(res);
                String[] sum = res.split("/");
                String aim = userId + "";
                for (int i = 0; i < sum.length; i++) {
                    if (aim.equals(sum[i])) {
                        flag = false;
                        break;
                    }
                }
                if (flag) {
                    res += "/" + aim;
                    String sql2 = "UPDATE groups SET member = '" + res + "' WHERE number =" + (groupid + 100000);
                    System.out.println(sql2);
                    Statement statement2 = connection.createStatement();
                    statement2.executeUpdate(sql2);

                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void add_new_group(String eventid, String name, String describe, String userId) {
        try {
            //String str2 = "select * from event"
            //statement.executeUpdate(str);
            String aim= String.valueOf((Integer.valueOf(eventid)+100000));
            String str = String.format("INSERT INTO groups VALUES (null, '%s', '%s', '%s', '%s')", aim, name, userId, describe);
            JDBC.getInstance().add(str);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static int getEventsIdByname(String name) {
        int n = 0;
        try {
            String sql = "select * from events where id IS null and title = '" + name + "'";
            Statement statement2 = null;
            statement2 = connection.createStatement();
            ResultSet resultSet = statement2.executeQuery(sql);
            while (resultSet.next()) {
                String id = resultSet.getString("id");
                n = Integer.parseInt(id);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return n;
    }
}
