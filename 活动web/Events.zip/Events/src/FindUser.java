import post.JDBC;
import post.Event;
import post.User;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FindUser extends HttpServlet {
    String jsp = "userList.jsp";

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int userId = 0;
        int eventId = 0;
        ArrayList<User> userList;
        try {
            userId = Integer.parseInt(request.getParameter("userid"));
            eventId = Integer.parseInt(request.getParameter("eventid"));
        } catch (Exception e) {//
        }
        if (eventId == 0) {
            userList = JDBC.getInstance().getUserList();
        } else {
            Event event = JDBC.getInstance().getEvent(eventId);
            userList = JDBC.getInstance().getUserList(event.getPartUserId());
        }
        request.setAttribute("userList", userList);
        request.setAttribute("userId", userId);
        request.getRequestDispatcher(jsp).forward(request, response);
    }
}